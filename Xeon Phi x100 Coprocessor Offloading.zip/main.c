/*
    Visual Stuido Project Template For Xeon Phi Offloading Programs.
    Extracted From Official Tutorials.
    2024/10/11, Resbi. 
*/
#include <stdio.h>

int main() {
    // Start your codes here... 
    return 0; 
}